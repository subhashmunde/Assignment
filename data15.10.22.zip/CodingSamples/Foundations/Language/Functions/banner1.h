typedef struct {
	float width;
	float height;
	char text[80];
}Banner;

double BannerPrice(Banner, int);

